/************************************************
*
* Author: Qiannan Wu
* Assignment: Program 0
* Class: CSI4321
*
************************************************/
package instayak.serialization;

import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

/**
 * Deserialization input source
 * 
 * @param sin The Scanner for the InputStream
 * 
 * @version 1.0 19 January 2017
 * @author Qiannan Wu
 */
public class MessageInput {

	private Scanner sin;
	/**
	 * Deserialization input source
	 * 
	 * @param in byte input source
	 * 
	 * @throws java.lang.NullPointerException If in is null
	 */
    public MessageInput(InputStream in) throws NullPointerException{
        sin = new Scanner(in, "ISO8859-1");
    }
    
    
    /**
     * Get One Message from the input source
     * 
     * @return Returns the first line of the message in String format and separated the line by spaces
     */
    public String[] getOneMessage() throws IOException{
    	if(sin.hasNextLine()){
    		String test = sin.nextLine();
    	    return test.split("\\s+");
    	}
    	else{
    		return null;
    	}
    }
    
    /**
     * Check if there is another line in Scanner
     * 
     * @return Returns true if Scanner has nextLine; otherwise false
     */
    public boolean hasNextMessage() throws IOException{
    	return sin.hasNextLine();
    }
}
