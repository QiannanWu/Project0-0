/************************************************
*
* Author: Qiannan Wu
* Assignment: Program 0
* Class: CSI4321
*
************************************************/
package instayak.serialization;

import java.io.IOException;

/**
 * Represents generic portion of InstaYak message and provides serialization/
 *     deserialization
 * 
 * @version 1.0 19 January 2017
 * @author Qiannan Wu
 * 
 */
public class InstaYakMessage {
    
	/**
	 * Constructs InstaYak message
	 */
	public InstaYakMessage(){
    }
    
	
	/**
	 * Deserializes message from input source
	 * 
	 * @param in deserialization input source
	 * 
	 * @return a specific InstaYak message resulting from deserialization
	 * 
	 * @throws InstaYakException if parse or validation problem
	 * @throws java.io.IOException if I/O problem
	 */
    public static InstaYakMessage decode(MessageInput in) throws InstaYakException, IOException{
    	String[] s = in.getOneMessage();
    	
    	if(s == null){
    		throw(new InstaYakException("Enpty MessageInput"));
    	}
    	
    	if(s.length != 2){
    		throw(new InstaYakException("Parsing Error"));
    	}
    	
    	if(s[0].equals("INSTAYAK")){
    		if(!s[1].equals("1.0")){
    			throw(new InstaYakException("Version validation fail"));
    		}
    		else{
    		    return new InstaYakVersion();
    		}
    	}
    	else if(s[0].equals("ID")){
    		if(s[1].length() < 1){
    			throw(new InstaYakException("ID validation fail"));
    		}
    		for(int i = 0; i < s[1].length(); ++i){
    			if(!Character.isDigit(s[1].charAt(i)) && !Character.isAlphabetic(s[1].charAt(i))){
    			    throw(new InstaYakException("ID validation fail"));
    			}
    		}
    		return new InstaYakID(s[1]);
    	}
    	else if(s[0].equals("CLNG")){
    		if(s[1].length() < 1){
    			throw(new InstaYakException("CLNG validation fail"));
    		}
    		
    		for(int i = 0; i < s[1].length(); ++i){
    			if(!Character.isDigit(s[1].charAt(i))){
    			    throw(new InstaYakException("CLNG validation fail"));
    			}
    		}
    		return new InstaYakChallenge(s[1]);
    	}
    	else{
    		throw(new InstaYakException("Unknown Operation"));
    	}
    }
    
    /**
     * Returns message operation
     * 
     * @return message operation
     */
    public String getOperation(){
		return "MESSAGE";
    }
    
    /**
     * Serializes message to given output sink. It does nothing here because children will implement this method
     *     and serializes specific message to given output sink.
     * 
     * @param out serialization output sink
     * 
     * @throws java.io.IOException if I/O problem
     */
    public void encode(MessageOutput out) throws java.io.IOException{
    	
    }   
}
