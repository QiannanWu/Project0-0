/************************************************
*
* Author: Qiannan Wu
* Assignment: Program 0
* Class: CSI4321
*
************************************************/
package instayak.serialization;

import java.io.IOException;

/**
 * Represents a InstaYakVersion and provides serialization/
 * deserialization
 * 
 * @param version the version information
 * 
 * @version 1.0 19 January 2017
 * @author Qiannan Wu
 *
 */
public class InstaYakVersion extends InstaYakMessage{
    private String version;
	/**
	 * Constructs version message
	 */
	public InstaYakVersion(){
		version = "1.0";
	}
	
	/**
	 * Constructs version message using deserialization. 
	 *     Only parses material specific to this message.
	 *     
	 * @param in deserialiazation input source
	 * 
	 * @throws InstaTakException
	 *      if parse or validation failure
	 * 
	 * @throws java.io.IOException
	 *      if I/O problem
	 */
	public InstaYakVersion(MessageInput in) throws InstaYakException, IOException{
		if(in == null){
    		throw(new NullPointerException());
    	}
		InstaYakMessage msg = InstaYakMessage.decode(in);
		if(msg.getOperation() != "INSTAYAK"){
        	throw(new InstaYakException("Wrong Operation"));
        }
        version = ((InstaYakVersion)msg).getVersion();
	}
	
	/**
	 * Returns a String representation ("InstaYak")
	 * 
	 * @return a string representation
	 */
	@Override
	public String toString(){
		return "InstaYak";
	}
	
	/**
	 * Returns version Message
	 * 
	 * @return a string of version
	 */
	public String getVersion(){
		return version;
	}
	
	/**
	 * Returns message operation
	 * 
	 * @return the message operation ("INSTAYAK")
	 */
	@Override
	public String getOperation(){
		return "INSTAYAK";
	}
	
	/**
	 * Serializes message to to given output sink
	 * 
	 * @param out serialization out put sink
	 * 
	 * @throws java.io.IOException if I/I problem
	 */
	@Override
	public void encode(MessageOutput out) throws java.io.IOException{
		String s = "INSTAYAK " + version + "\r\n";
		byte[] encoding = s.getBytes("ISO8859-1");
		out.write(encoding);
	}
	
	/**
	 * 
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((version == null) ? 0 : version.hashCode());
		return result;
	}

	/**
	 * Override equals methods for InstaYakVersion class
	 * 
	 * @param v the object needs to be compared
	 * 
	 * @return true/false if they have the same version value, return true; otherwise
	 *             return false;
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		InstaYakVersion other = (InstaYakVersion) obj;
		if (version == null) {
			if (other.version != null)
				return false;
		} else if (!version.equals(other.version))
			return false;
		return true;
	}
	
	
}
