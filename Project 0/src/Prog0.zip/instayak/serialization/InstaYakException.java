/************************************************
*
* Author: Qiannan Wu
* Assignment: Program 0
* Class: CSI4321
*
************************************************/
package instayak.serialization;

/**
 * Exception for InstaYak handling
 * 
 * @param serialVersionUID the default serial Version UID
 * 
 * @version 1.0 19 January 2017
 * @author Qiannan Wu
 */
public class InstaYakException extends Exception {
	private static final long serialVersionUID = 1L;

	/**
     * Constructs InstaYak exception
     * @param message exception message
     * @param cause exception cause
     */
	public InstaYakException(String message, Throwable cause){
		
    }
    
	 /**
     * Constructs InstaYak exception
     * @param message exception message
     */
    public InstaYakException(String message){
    	
    }
}
